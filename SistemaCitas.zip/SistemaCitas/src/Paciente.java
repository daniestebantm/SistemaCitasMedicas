
import java.util.Scanner;

public class Paciente {
    Scanner scanner = new Scanner(System.in);
    private String nombre;
    private int edad;
//constructor
    /*public Paciente(Scanner scanner, String nombre, int edad) {
        this.scanner = scanner;
        this.nombre = nombre;
        this.edad = edad;
    }
    */

    public void ingresarNombre(){
        boolean nombreValido = false;
        while (!nombreValido){
            try{
                System.out.println("Ingrese el nombre del paciente: ");
                nombre = scanner.nextLine();
                //
                if(nombre.matches("^[a-zA-Z]+$")){
                    throw new NombreInvalidoException("El nombre no está bien escrito");
                }
                if(nombre != null || !nombre.trim().isEmpty()){
                    throw new NombreInvalidoException("El nombre está vacío");
                }
                nombreValido = true;
            }
            catch(NombreInvalidoException mensaje){
                System.out.println("Error: "+mensaje.getMessage());
                System.out.println("Por favor, intente de nuevo");
            }
        }
    }
    public  void ingresarEdad(){
        boolean edadValida = false;

        while (!edadValida){
            try{
                System.out.println("Ingrese la edad del paciente: ");
                edad = scanner.nextInt();
                if(edad>110 || edad<0){
                    throw new EdadInvalidaException("Edad inválida, no puede tener esa edad");
                }
                if(edad<18){
                    throw new EdadInvalidaException("Edad inválida, debe ser mayor de edad");
                }
                edadValida = true;
            }
            catch (EdadInvalidaException mensaje){
                System.out.println("Error: "+ mensaje.getMessage());
                System.out.println("Por favor intente de nuevo");
            }
        }
    }
}
