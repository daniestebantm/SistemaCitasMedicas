public class Doctor {
    String nombre;
    String especialidad;
    boolean disponibilidad;

    //constructor parametrizado

    public Doctor(String nombre, String especialidad, boolean disponibilidad) {
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.disponibilidad = disponibilidad;
    }

}
