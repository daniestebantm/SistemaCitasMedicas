import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Paciente paciente1 = new Paciente();
        paciente1.ingresarNombre();
        paciente1.ingresarEdad();
        /*Doctor doctor1 = new Doctor();
        doctor1.*/
    }
}