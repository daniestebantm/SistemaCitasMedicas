import java.lang.classfile.constantpool.LoadableConstantEntry;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Cita {
    Scanner scanner = new Scanner(System.in);
    Paciente paciente;
    Doctor doctor;
    int horario;

    public Cita(Paciente paciente, Doctor doctor, int horario) {
        this.paciente = paciente;
        this.doctor = doctor;
        this.horario = horario;
    }

    public void agendarCita(){
        boolean horarioValido = false;
        while(!horarioValido){
            try{
                System.out.println("En que horario desea su cita");
                horario = scanner.nextInt();
                //validar formato
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
                //horario de citas[08:00-21:00]
                if(horario.isBefore(LocalTime.of()))
            }
        }
    }
}
